import React from 'react';
import './ActionButtons.css'; 

const ActionButtons = () => {
  return (
    <div className="action-buttons">
      <button className="btn buy-now">Buy Now</button>
      <button className="btn contact">Contact</button>
    </div>
  );
};

export default ActionButtons;
