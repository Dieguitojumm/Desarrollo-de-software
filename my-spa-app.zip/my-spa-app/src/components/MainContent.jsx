import React from 'react';
import computadorImg from '../assets/Imagenes/computadores.png'; // Ajusta la ruta según la ubicación del archivo

const MainContent = () => {
  return (
    <div className="main-content">
      <h2>Computer And Laptop</h2>
      <h1>Accessories</h1>
      <p>
        There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour…
      </p>
      <img src={computadorImg} alt="Devices" className="main-image" />
    </div>
  );
};

export default MainContent;

