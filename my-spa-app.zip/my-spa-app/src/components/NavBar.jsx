import React from 'react';
import './NavBar.css'; // Para los estilos

const NavBar = () => {
  return (
    <nav className="navbar">
      <h1>CLA</h1> {/* Logo o título */}
      <ul className="nav-links">
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Computer</a></li>
        <li><a href="#">Laptop</a></li>
        <li><a href="#">Products</a></li>
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Login</a></li>
      </ul>
    </nav>
  );
};

export default NavBar;
