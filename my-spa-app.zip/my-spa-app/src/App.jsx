import React from 'react';
import './App.css'; // Para los estilos globales
import NavBar from './components/NavBar';
import MainContent from './components/MainContent';
import ActionButtons from './components/ActionButtons';

function App() {
  return (
    <div className="App">
      <NavBar />
      <MainContent />
      <ActionButtons />
    </div>
  );
}

export default App;

